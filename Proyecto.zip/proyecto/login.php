<?php
// Conexión a la base de datos
include ('db.php');

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

if (isset($_POST['login'])) {
    $email = $_POST['correo'];
    $contrasena = $_POST['contra'];
    
    
    $consulta = "SELECT usuarios.id, usuarios.nombre, usuarios.apellido, usuarios.CC , usuarios.asunto, usuarios.estado_cuenta, servicios.servicio FROM usuario_servicio
    INNER JOIN usuarios ON usuario_servicio.id_usuario = usuarios.id
    INNER JOIN servicios ON usuario_servicio.id_servicio = servicios.id
    WHERE usuarios.correo='$email'
     AND usuarios.contraseña='$contrasena'";
    $resultado = $conexion->query($consulta);
    
    

    if ($resultado->num_rows == 1) {
        $usuario = $resultado->fetch_assoc();
        session_start();
        $_SESSION['usuario_id'] = $usuario['id'];
        $_SESSION['nombre'] = $usuario['nombre'];
        $_SESSION['apellido'] = $usuario['apellido'];
        $_SESSION['asunto'] = $usuario['asunto'];
        $_SESSION['estado-cuenta'] = $usuario['estado_cuenta'];
        $_SESSION['servicio'] = $usuario['servicio'];

        header("Location: usuarios.php"); // Redirige al usuario a una página de inicio
    } else {
        echo "Credenciales incorrectas.";
    }
}

$conexion->close();
?>
