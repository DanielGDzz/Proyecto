<?php
session_start();
if(!isset( $_SESSION['nombre'])){

    header("location: index.HTML");
    exit();
}

$nombreu = $_SESSION['nombre'];
$mensaje = $_SESSION['asunto'];
$apellidou =  $_SESSION['apellido'];
$estadoc = $_SESSION['estado-cuenta'];
$serviciou =$_SESSION['servicio']

?>


<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
   
    <link rel="stylesheet" href="estilos/usuarios1.css">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <link rel="shortcut icon" href="imagenes/FB_IMG_1692122787529.jpg" type="image/x-icon">
    <title>Usuario || Marketing digital M&M</title>
</head>
<body>
<div class="header">
    <img class="logo" src="imagenes/FB_IMG_1692122787529.jpg" alt="Logo">
    <div class="header-text">Marketing digital Magdalena Medio 
         <p>  || Panel usuario ||  </p></div>
       
   
  </div>
  <main class="main"> 
    <section class="izquierda">  <!--PARTE IZQUIERDA DE LA PAGINA-->
      <section class="fotoperfil">
      <img src="imagenes/usuariosperfil.png" height="200px">
      </section>  
      <h1 align="center"><?php echo $nombreu; ?> ‎  <?php echo $apellidou;?></h1>    
     <div class="lista">
        <ul>
            <li>
            <p> <a class="a" href="index.html">Volver al inicio</a></p>
            </li>
            <li>
            <p> <a class="a" href="contacto.html">Contacto</a></p>
            </li>
            <li>
            <p> Elegir servicio</p>
            </li>
            <li>
            <p>Ajustes de cuenta</p>
            </li>
            <li>
            <p> <a class="a" href="logout.php">Cerrar sesion</a></p>
            </li>
        </ul>
     </div>

    </section> <!--PARTE IZQUIERDA DE LA PAGINA-->



<section class="derecha"><!--PARTE DERECHA DE LA PAGINA-->
<section class="superiord"> 
<h2> Bienvenido usuario: <?php echo $nombreu; ?>  </h2>
</section>

       
<section class="detalles"><!--detalles-->
<section class="detallesiz"><!--detalles izquierdo-->
<section class="detallesiz1">
<h2> Estado de cuenta: <?php echo $estadoc; ?>  </h2>
</section>
<section class="detallesiz2">
<h2> Servicio adquirido: <?php echo $serviciou; ?>  </h2>
</section>
</section><!--detalles izquierdo-->

<section class="detallesder"> <!--detalles derecho-->
<h1> Tu asunto: </h1>
<br>
<p><?php echo $mensaje; ?></p>

</section> <!--detalles derecho-->
</section><!--detalles-->

<section class="datosp">


</section>
</section><!--PARTE DERECHA DE LA PAGINA-->
   
     


</main>
</body>
</html>