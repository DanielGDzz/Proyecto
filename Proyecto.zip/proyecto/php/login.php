<?php
// Conexión a la base de datos
include ('db.php');

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $contrasena = $_POST['contrasena'];
    
    
    $consulta = "SELECT id, nombre FROM usuarios WHERE email='$email' AND contraseña='$contrasena'";
    $resultado = $conexion->query($consulta);
    
    

    if ($resultado->num_rows == 1) {
        $usuario = $resultado->fetch_assoc();
        session_start();
        $_SESSION['usuario_id'] = $usuario['id'];
        $_SESSION['nombre'] = $usuario['nombre'];
        header("Location: index.HTML"); // Redirige al usuario a una página de inicio
    } else {
        echo "Credenciales incorrectas.";
    }
}

$conexion->close();
?>
