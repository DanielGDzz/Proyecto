<?php
include ('db.php');

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

if (isset($_POST['register'])) {
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $cc = $_POST['cc'];
    $correo = $_POST['correo'];
    $contrasena =$_POST['contraseña'];
    $telefono =$_POST['cel'];
    $asunto = $_POST['asunto'];
    $sql = "INSERT INTO usuarios (nombre, apellido, CC, correo, contraseña, telefono, asunto, estado_cuenta) VALUES 
    ('$nombre','$apellido', '$cc', '$correo', '$contrasena', '$telefono', '$asunto', 'Esperando servicio')";
    
    $conexion ->query($sql);


    if ($conexion->affected_rows ==1 ) {
        $idnewnombre = $conexion -> insert_id;
  $otraconsulta = "INSERT INTO usuario_servicio (id_usuario, id_servicio) VALUES 
  ($idnewnombre, 5)";
  $cualquiera = $conexion->prepare($otraconsulta);
        if ($cualquiera->execute())
        header("Location: Index.HTML");
        echo "Registro exitoso!";
    } else{
        echo "No sirvio, parcero";
    }
    
}
$conexion->close();
header("Location: prueba.html");
?>


